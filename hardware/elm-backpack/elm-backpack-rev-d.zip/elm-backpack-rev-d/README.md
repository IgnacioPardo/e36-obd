# Black ECU adapter — revision D

110 × 82 × 30.4 mm. Direct-solder ESP32; USB faces away from the OBD plug.

Plain black casing, black fasteners and straps, side ventilation, and the retained BMW-and-stripes lid detail. The broad lid grille, cosmetic side pockets and extra caption are removed.

- [Interactive 3D viewer](hardware/elm-backpack/viewer.html)
- [Assembled, open and exploded views](hardware/elm-backpack/exports/preview.png)
- [All-black finish without silver paint](hardware/elm-backpack/exports/black.png)
- [Print layout — 1 base, 1 lid, 4 keepers](hardware/elm-backpack/exports/print-layout.3mf)
- [Print the fit gauge first](hardware/elm-backpack/exports/fit-gauge.stl)
- [Printing, finishing and assembly](hardware/elm-backpack/README.md)
- [Measurements, sources and design plan](hardware/elm-backpack/PLAN.md)

STL, STEP, parameters and CAD source are included. The BMW lettering and stripes are printable geometry. Silver faces are optional paint, omitted from print meshes; one filament is sufficient. Rendered plastic texture and reference electronics are illustrative.

Physical fit remains provisional: verify actual boards, capacitor height, solder joints and drilled-hole position before the full print.
