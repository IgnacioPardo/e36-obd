# E36 — M50-style revision C

110 × 82 × 30.4 mm. Direct-solder ESP32; USB faces away from the OBD plug.

- [Interactive viewer with silver/all-black toggle](hardware/elm-backpack/viewer.html)
- [Assembled, open and exploded views](hardware/elm-backpack/exports/preview.png)
- [All-black finish](hardware/elm-backpack/exports/black.png)
- [Print layout — 1 base, 1 lid, 4 keepers](hardware/elm-backpack/exports/print-layout.3mf)
- [Print the fit gauge first](hardware/elm-backpack/exports/fit-gauge.stl)
- [Printing, finishing and assembly](hardware/elm-backpack/README.md)
- [Sources and design plan](hardware/elm-backpack/PLAN.md)

The ribs and BMW lettering are real printable geometry. Silver faces are optional paint; one material is sufficient. Rendered plastic grain is illustrative. STL, STEP, parameters and CAD source are included. Paint reference surfaces are omitted from print files.

Physical fit remains provisional: verify actual boards, capacitor height, solder joints and drilled-hole position before the full print.
