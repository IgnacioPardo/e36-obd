# ELM327 backpack — M50-style revision C

**110 × 82 × 30.4 mm enclosure for the buck converter and ESP32-S3 shown in the photos.** It straps to the plain back of the existing ELM housing, leaves the OBD plug exposed, and takes the tail wires through a large opening in its floor.

**Direct-solder version: remove the ESP32 header strips and jumper housings. USB faces the wire-exit end, away from the OBD plug.** Compared with the header version, height drops from 34.8 to 30.4 mm. The buck capacitor allowance sets the remaining height.

**First-fit prototype: physical dimensions are not yet confirmed.** The buck layout uses 63.5 × 27.5 mm and the ESP uses a 65 × 28 mm overall envelope. These come from related seller dimensions and photo scaling, with explicit allowances. The ELM body is an unmeasured reference. [PLAN.md](PLAN.md) records the sources, discrepancies, design decisions, and remaining measurements.

**M50-inspired exterior:** black plastic, small clipped corners, shallow side panels, nine parallel lid ribs around the BMW lettering, and a recessed `E36` caption. The silver faces in the render are **optional paint**; all six printed parts use one material. The fine stippled surface in the render is a material preview, not mesh texture.

![Assembled, open and exploded CAD views](exports/preview.png)

## Open these files

| File | Purpose |
|---|---|
| [black.png](exports/black.png) | All-black finish preview, without silver paint. |
| [viewer.html](viewer.html) | Offline interactive 3D viewer. Drag to orbit; switch between closed, open and exploded views. No libraries, account or network needed. |
| [print-layout.3mf](exports/print-layout.3mf) | Printable geometry only: **1 base + 1 lid + 4 buck keepers**, arranged flat. Choose your own printer and filament profile. |
| [fit-gauge.stl](exports/fit-gauge.stl) | Small first print for board outlines and M3 holes. |
| [base.stl](exports/base.stl), [lid.stl](exports/lid.stl), [buck-keeper.stl](exports/buck-keeper.stl) | Separate millimetre meshes, already in print orientation. Print the keeper four times. |
| [assembly-with-references.step](exports/assembly-with-references.step) | CAD assembly with individually named printed parts, electronics, optional paint surfaces, straps and ELM reference. **Do not print the whole reference assembly.** |
| [base.step](exports/base.step), [lid.step](exports/lid.step), [buck-keeper.step](exports/buck-keeper.step) | Editable solids, in print orientation. |
| [dimensions.svg](exports/dimensions.svg) | Layout and clearance sheet. |
| [parameters.json](parameters.json), [model.py](model.py) | Editable parametric dimensions and CAD generator. |

## Hardware and pads

| Quantity | Item | Use |
|---|---|---|
| 4 | Black M3 × 10 pan/button-head screws, head diameter ≤5.6 | Lid; thread gently into the 2.6 mm printed pilots |
| 4 | M3 × 6 pan/button-head screws, head diameter ≤5.6 | Buck keepers |
| 2 | Reusable hook-and-loop straps, 10 mm wide, about 350 mm long | Around the printed case and ELM; trim after checking overlap |
| 1 | Nylon tie, about 2.5 × 150 mm | ESP retention over the RF metal shield |
| 1 | Nylon tie, about 2.5 × 100 mm | Harness strain relief on the internal bridge anchor |
| 4 | Insulating silicone pads, about 10 × 16 × 3 mm | Between the ELM back and case floor; leave tie and wire routes clear |
| 4 + 4 | Small 0.5 mm silicone pads, about 1 × 5 mm | Buck underside edge supports and keeper toes; upper pads compress into a 0.3 mm gap |
| 2 | 0.5 mm silicone pads, about 14 × 6 mm | Under the ESP's central bare back area |
| As needed | Thin insulating sleeve/pad for ties; grommet or edge sleeve for the drilled ELM hole | Avoid rubbing insulation or loading components |

The tiny buck keeper toes touch only the outer 1 mm of PCB. Check those exact edge strips on the real board; move `buck_clamp_fraction` if a component, lead or solder joint occupies a contact patch. Do not clamp over the inductor or capacitor. The ESP's support columns deliberately stay between its two pin rows.

## Print and check

1. Print **fit-gauge.stl** at 100% in millimetres. With the connecting bar and two raised hole bosses at the far end, the **left pocket is the buck**, the **right is the ESP**. Each pocket adds 0.3 mm per side to the nominal outline. The left boss is the 2.6 mm screw pilot; the right is 3.4 mm clearance. Test an M3 screw by hand. If your printer closes the holes, adjust the diameters rather than forcing the screws.
2. Check both boards against the pockets. For the ESP, check the total antenna-to-USB envelope as well as the shorter carrier PCB. This gauge does **not** prove solder, connector, pad or height clearance. Measure the actual capacitor height, solder-joint height and wire bend space and the carrier-PCB end before the full print.
3. Start with a 0.4 mm nozzle, 0.20 mm layers, 4 walls, 5 top/bottom layers and 30% gyroid. Base: flat floor on the bed. Lid: outer face on the bed, rim upward. Keepers: flat. The lid ribs, wordmark and outer border all sit on the first-layer plane. The 0.4 mm recessed field closes with short bridges between them; inspect the spaces around the lettering in preview. Use a smooth plate for the detail. The two recessed belt lanes require about 12 mm of bridging near the bed; the tie anchor has a 3 mm bridge and side vents have 2.4 mm bridges. Add local support under the shared 32 mm USB-window roof; it is accessible from the rear for removal. Other structural supports are not intended. Inspect those bridges in the slicer and use a brim where your material needs one.
4. Prefer unfilled ASA for the car installation, using its manufacturer's profile and an enclosed printer. [Prusa's ASA guide](https://help.prusa3d.com/article/asa_1809) explains its heat resistance and printing requirements. PETG is an alternative for a cool bench fit check. Confirm the finished assembly temperature for the actual vehicle installation; the vents do not establish a continuous 5 A rating.
5. Import `print-layout.3mf` as geometry, select the correct printer/filament, and check scale. Base should read **82 × 110 × 28**; lid **82 × 110 × 4.4** in print orientation. The lid's 2 mm rim goes inside the base, so the assembled enclosure height is **30.4**, not 32.4. Rearrange parts if your bed, brim or exclusion zones require it. No G-code or machine settings are supplied.

## Assemble, unpowered

1. Test the empty lid, its rim and all eight screw positions. The rim has 0.35 mm clearance per side. Screws should seat with light hand torque; do not drive them into a bottomed-out hole.
2. Protect the existing hole in the ELM shell. Label the connections, remove the ESP header strips and jumper housings, and pass the wires through the 22 × 20 floor opening before soldering directly to the ESP pads or very short pin stubs. Insulate each joint and follow the existing [wiring diagram](../../docs/cableado.html). The case is oriented with both ESP USB sockets toward the wire-exit end, away from the OBD plug. The wire-entry end overhangs the ELM tail.
3. Apply the small buck support pads, place the converter component side up with **input/DC-jack end toward the wire entry**, and fit the four padded keepers. Verify the keeper toes and lower ledges only touch clear board edges. Tighten just enough to stop movement.
4. Apply the two ESP support pads. Place the ESP **component side up, with direct-solder wires routed parallel to its underside**. Confirm that the two rear stops meet the carrier PCB beside the antenna and that both USB sockets line up with the rear USB window. Loop the small tie through the two floor slots and over the **metal RF shield**, with a protective sleeve. Keep the antenna and buttons clear. Snug it without bending the board. The solder-joint envelope is 1.5 mm below the PCB, leaving 3.5 mm for the insulated wire run; no full-length headers or Dupont housings fit this profile.
5. Pass a second small tie through the sideways tunnel in the harness anchor and around the insulated wire bundle above it. Keep slack between that anchor and the ELM's drilled hole. Route the buck's terminal leads into the reserved spaces at its ends. Do not trap wires in the lid rim, keeper screws or USB opening.
6. Fit the four 3 mm mounting pads to the ELM's plain back. Leave the underside ESP tie clear. Position the case so the floor opening sits just beyond the tail hole; slide it slightly as required. Check the OBD plug and its mating adapter remain unobstructed.
7. Fit the lid using four M3 × 10 screws. Wrap the two reusable straps around **both housings** in the belt grooves; their closure sits on the ELM side. Keep both straps on the ELM body, clear of its plug. Undo the straps before removing the lid for service.
8. Check the actual USB cable overmold enters the notch and mates fully. Recheck wiring, then run the existing firmware under the intended load with the lid closed. Check temperature and Wi-Fi/BLE reception in the actual mounting position before installing permanently.

## Verification performed

- Every printed CAD part is a single valid solid.
- Every STL is closed, has consistent triangle winding, one connected component and positive volume; all start at the print bed.
- Printed assembly parts have no detected mutual overlaps or overlaps with the modelled PCB, component, solder and USB mating-plug envelopes. See [cad-validation.json](exports/cad-validation.json).
- The 3MF was reopened and checked for mm units, three object definitions, and six placed parts. Import it through **File → Import → Import 3MF/STL/STEP** in Bambu Studio as geometry. It has not been sliced for a specific printer. See [mesh-validation.json](exports/mesh-validation.json).
- Actual mesh renders and the interactive viewer were inspected. Detailed cable bends, the real ELM hole, physical contact areas and thermal/RF performance require a physical check.

Nominal clearances: **2 above the buck envelope**, **14 above the ESP envelope**, **3.5 below the ESP solder joints for wires**, and **1 below the buck solder envelope**. These are design allowances, not measurements of the user's parts.

## Regenerate

From the repository root, using the existing CAD environment:

```sh
PYTHONDONTWRITEBYTECODE=1 ./.cadenv/bin/python hardware/elm-backpack/model.py
python3 hardware/elm-backpack/package.py
PYTHONDONTWRITEBYTECODE=1 ./.cadenv/bin/python hardware/elm-backpack/build_visuals.py
```

For fresh renders, then rebuild the contact sheet:

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b --factory-startup -t 6 --python hardware/elm-backpack/render.py
PYTHONDONTWRITEBYTECODE=1 ./.cadenv/bin/python hardware/elm-backpack/build_visuals.py
```

`model.py` uses build123d 0.11.1 on Python 3.12. `package.py` uses only the standard library; contact-sheet generation also uses Pillow. `build_visuals.py` embeds the CAD meshes in the HTML, so the viewer works by opening the file directly. Change values in `parameters.json` to match your measured parts, regenerate, and review any reported interference before printing.

## Height adjustment and the older header profile

`auto_height` calculates the case roof from the taller board envelope plus 2 mm. `buck_top_allowance` is the height **above the top of the buck PCB**, not the entire board thickness. It is currently a conservative 18 mm; if you measure 14 mm, changing that value yields a 26.4 mm enclosure. Measure before reducing it.

The original header dimensions remain in `profiles/headers.json`. To generate that variant separately, run `model.py --parameters hardware/elm-backpack/profiles/headers.json --out hardware/elm-backpack/exports-headers`. That profile retains the original front-facing USB arrangement. Current exports and previews are the M50-style, lower, rear-USB revision C. The previous plain-shell parameters are in `profiles/rev-b.json`; the complete prior delivery remains in `elm-backpack-rev-b.zip`.

## Finish the M50-style cover

Print the base, lid and keepers in black. Leave the 0.4 mm recessed lid field dark. For the silver version shown, lightly highlight **only the nine rib tops and BMW letter faces** with a compatible silver paint marker or a nearly dry small roller. The geometry stands proud of that recessed field, so the paint can stay off its background. Keep the ventilation gaps open. Allow the finish to cure before fitting the straps. No second filament or separate badge is required.

The lid's plate remains 2.4 mm thick; the decorative field leaves 2.0 mm, and the existing belt grooves leave 1.8 mm. The side pockets remove 0.35 mm and leave 2.05 mm walls there. The 2.5 mm clipped outer corners do not change the internal rounded rim, screw centres, board seats, floor, wire entry or rear USB interface. The paired vent bank and openings between the short rib ends provide about 737 mm² of lid openings (excluding screws), versus about 391 mm² in B; this is geometric open area, not a thermal rating.

The small caption uses Arial Bold outlines. Regeneration uses the macOS Arial Bold font when present, with a system Arial Bold fallback; STL and STEP files already contain the lettering geometry. The paint surfaces in the reference STEP are named `REF optional silver...` and excluded from print files. In the viewer, toggle **Silver highlights** to compare finishes.
