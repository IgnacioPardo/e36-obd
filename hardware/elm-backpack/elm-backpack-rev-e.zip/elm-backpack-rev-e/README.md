# E36 inline ECU adapter — revision E

162 × 48 × 30.4 mm. Black enclosure with the buck and ESP end-to-end, underside mounting and lid screws, BMW ribbed cover, direct soldering and rear USB.

- [Interactive 3D viewer](hardware/elm-backpack/viewer.html)
- [Actual CAD previews](hardware/elm-backpack/exports/preview.png)
- [Before/after comparison](hardware/elm-backpack/exports/comparison.png)
- [All-black finish](hardware/elm-backpack/exports/black.png)
- [Print layout: 1 base + 1 lid + 4 keepers](hardware/elm-backpack/exports/print-layout.3mf)
- [Print the fit gauge first](hardware/elm-backpack/exports/fit-gauge.stl)
- [Dimensions](hardware/elm-backpack/exports/dimensions.svg)
- [Printing, hardware and assembly](hardware/elm-backpack/README.md)
- [Measurement sources and design plan](hardware/elm-backpack/PLAN.md)

Width is 41% less than D, length is 52 mm greater, height unchanged. Support the extended tail at the provided rear tie position using a suitable existing mount. Physical board fit, ELM geometry and vehicle space need checking before the full print. The BMW/rib silver finish is optional paint; it is excluded from print meshes. Renders use the actual CAD with illustrative fine plastic grain. No printer profile or G-code is included.
