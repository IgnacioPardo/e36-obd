# ELM backpack — revision B

110 × 82 × 30.4 mm. Direct-solder ESP32; USB faces away from the OBD plug.

- [Open the interactive viewer](hardware/elm-backpack/viewer.html)
- [Preview](hardware/elm-backpack/exports/preview.png)
- [Print layout — 1 base, 1 lid, 4 keepers](hardware/elm-backpack/exports/print-layout.3mf)
- [Print the fit gauge first](hardware/elm-backpack/exports/fit-gauge.stl)
- [Assembly and printing instructions](hardware/elm-backpack/README.md)
- [Dimensions, sources, and design plan](hardware/elm-backpack/PLAN.md)

STL, STEP, editable parameters, and CAD source are in hardware/elm-backpack.
Physical fit is provisional: verify the real boards, capacitor height, solder joints, and drilled-hole position before the full print.
