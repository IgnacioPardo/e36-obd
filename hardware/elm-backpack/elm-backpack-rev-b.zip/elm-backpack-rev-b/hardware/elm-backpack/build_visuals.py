"""Build an offline CAD viewer, dimension sheet, and render contact sheet."""
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT = HERE / 'exports'
scene = json.loads((OUT / 'scene.json').read_text())
p = scene['parameters']
W,L,H,F,LT = (p[k] for k in ('case_width','case_length','base_height','floor','lid_thickness'))
size = f'{L:g} × {W:g} × {H+LT:g}'
wire_size = f"{p['wire_entry_width']:g} × {p['wire_entry_length']:g}"
template = (HERE / 'viewer.html.in').read_text()
template = template.replace('110 × 82 × 30.4',size).replace('22 × 20',wire_size)
(HERE / 'viewer.html').write_text(template.replace('__SCENE_DATA__',(OUT / 'scene.json').read_text()))
svg = ['''<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="870" viewBox="0 0 1200 870"><defs><marker id="a" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L8 4L0 8" fill="none" stroke="#557482"/></marker></defs><style>text{font-family:Arial,sans-serif;fill:#253e4c}.dim{stroke:#557482;stroke-width:1;marker-start:url(#a);marker-end:url(#a)}.lead{fill:none;stroke:#8399a3;stroke-width:1.2}</style><rect width="1200" height="870" fill="#f4f7f8"/>''']
def text(x,y,s,size=14,color='#253e4c',bold=False):
    svg.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{"bold" if bold else "normal"}">{s}</text>')
def box(x,y,w,h,fill,stroke='#537081',r=2):
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="1.3"/>')
def plan_box(x,y,w,l,color,r=2):
    box(275+4*(x-w/2),400-4*(y+l/2),4*w,4*l,color,r=r)
def dim(x1,y1,x2,y2,label,tx,ty):
    svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="dim"/>')
    text(tx,ty,label,15)
def lead(points,label,x,y):
    svg.append(f'<polyline points="{points}" class="lead"/>')
    text(x,y,label,13)
text(52,52,'E36 / HARDWARE · REV B',12,bold=True)
text(52,90,'ELM backpack · rear USB / direct solder',29,bold=True)
text(52,117,'All dimensions in mm. Nominal references; physical fit check required. Not a 1:1 paper template.',13,'#6c7f88')
text(110,158,'TOP · LID REMOVED',14,bold=True)
plan_box(0,0,W,L,'#d8e2e8',20)
plan_box(0,0,W-2*p['wall'],L-2*p['wall'],'#edf2f4',10)
plan_box(p['wire_entry_x'],p['wire_entry_y'],p['wire_entry_width'],p['wire_entry_length'],'#fff',10)
for name,color in (('buck','#9cbbcf'),('esp','#afc7be')):
    x,y,w,l = (p[f'{name}_{k}'] for k in ('x','y','width','length'))
    plan_box(x,y,w,l,color)
    text(275+4*x-32,400-4*y-2,'BUCK' if name=='buck' else 'ESP32-S3',13,bold=True)
    text(275+4*x-35,400-4*y+18,f'{l:g} × {w:g}',12)
for side in (-1,1):
    for off in (-p['buck_clamp_fraction'],p['buck_clamp_fraction']):
        plan_box(p['buck_x']+side*(p['buck_width']/2+3.7),p['buck_y']+off*p['buck_length'],6.4,6.4,'#e7a479')
for y in p['strap_y']:
    for x in (-W/2,W/2): plan_box(x,y,1.2,p['strap_lane_width'],'#526779')
# Tail USB, bottom wire entry, and antenna are now on the correct ends.
plan_box(p['esp_x'],L/2,32,1.2,'#253e4c')
antenna_y=p['esp_y']-p['esp_length']/2+p['esp_antenna_overhang']/2
plan_box(p['esp_x'],antenna_y,18,p['esp_antenna_overhang'],'#71998a')
text(195,231,wire_size,12)
dim(275-2*W,652,275+2*W,652,f'{W:g}',258,675)
dim(76,400-2*L,76,400+2*L,f'{L:g}',43,405)
lead('350,180 450,180 475,170','USB → wire-exit end',482,171)
lead('245,242 455,242 475,255','22 × 20 floor entry',482,260)
lead(f'350,{400-4*antenna_y} 452,{400-4*antenna_y} 476,460','Antenna: keep free',482,464)
text(145,711,'OBD PLUG / VEHICLE END',13,'#6c7f88',True)
text(722,158,'SECTION · ACROSS THE BOARDS',14,bold=True)
scale,cx,zbase=4,886,560
box(cx-W*2,zbase-H*scale,W*scale,H*scale,'#d8e2e8')
box(cx-W*2+p['wall']*scale,zbase-H*scale,(W-2*p['wall'])*scale,(H-F)*scale,'#f4f7f8','#f4f7f8',0)
box(cx-W*2,zbase-(H+LT)*scale,W*scale,LT*scale,'#829aaa')
for name,fill in (('buck','#7da5be'),('esp','#90b6a6')):
    x,w=p[name+'_x'],p[name+'_width']
    z=F+p[name+'_under_board']; top=p[name+'_top_allowance']
    xx=cx+scale*(x-w/2)
    box(xx,zbase-(z+p['pcb_thickness'])*scale,w*scale,p['pcb_thickness']*scale,fill)
    box(xx+8,zbase-(z+p['pcb_thickness']+top)*scale,w*scale-16,top*scale,'#dce5e9','#8fa5af')
    if name=='esp':
        box(cx+scale*(x-7),zbase-z*scale,56,(z-F)*scale,'#c0ced5')
        for side in (-1,1):
            px=cx+scale*(x+side*p['esp_pin_row_spacing']/2)-3
            box(px,zbase-z*scale,6,p['esp_connector_depth']*scale,'#667981')
dim(1083,zbase-(H+LT)*scale,1083,zbase,f'{H+LT:g}',1096,503)
text(780,413,f'{LT:g} lid',13,'#6c7f88')
text(770,591,f'{F:g} floor · {p["wall"]:g} walls',13,'#6c7f88')
text(772,634,'Buck',14,bold=True)
text(772,659,f'{p["buck_under_board"]:g} under PCB / {p["buck_top_allowance"]:g} above',13)
text(772,698,'ESP32 · headers removed',14,bold=True)
text(772,723,f'{p["esp_under_board"]:g} under PCB: {p["esp_connector_depth"]:g} solder joints',13)
text(772,744,f'+ {p["esp_under_board"]-p["esp_connector_depth"]:g} for insulated wires',13)
svg.append('<line x1="52" y1="786" x2="1148" y2="786" stroke="#c6d3d9"/>')
text(52,818,'Print 1 base + 1 lid + 4 keepers. Local removable support is needed beneath the USB-window roof.',13)
text(52,841,'Capacitor height sets the enclosure height. Measure before reducing it. See PLAN.md for sources and assumptions.',13,'#6c7f88')
svg.append('</svg>')
(OUT/'dimensions.svg').write_text(''.join(svg))
if all((OUT/(n+'.png')).exists() for n in ('assembled','interior','exploded')):
    from PIL import Image,ImageDraw,ImageFont
    sheet=Image.new('RGB',(2400,1120),'#e9eef0'); d=ImageDraw.Draw(sheet)
    path='/System/Library/Fonts/Supplemental/Arial.ttf'
    large,medium,small=[ImageFont.truetype(path,n) for n in (48,31,24)]
    d.text((60,42),'E36 / ELM BACKPACK',font=large,fill='#243947')
    d.text((60,107),f'{size} mm · Direct-solder ESP32 · Rear USB · REV B / FIT CHECK REQUIRED',font=small,fill='#6a7d87')
    for i,(name,label) in enumerate((('assembled','01 / USB at wire-exit end'),('interior','02 / Lid removed'),('exploded','03 / Exploded assembly'))):
        im=Image.open(OUT/(name+'.png')).convert('RGB'); im.thumbnail((760,760))
        sheet.paste(im,(30+i*790+(760-im.width)//2,225))
        d.text((60+i*790,168),label,font=medium,fill='#243947')
    d.text((60,1017),'Editable CAD + STL + 3MF. ELM and board models are provisional references.',font=small,fill='#465f6c')
    d.text((60,1058),'Harness is illustrative. Verify board sizes, capacitor height, solder joints and contact areas before full print.',font=small,fill='#6a7d87')
    sheet.save(OUT/'preview.png')
print('Built viewer.html, dimensions.svg and render contact sheet.')
